package onlineCabBookingLLD.strategy;

public interface PriceStrategy {

	public double calculatePrice(double distance);
}
